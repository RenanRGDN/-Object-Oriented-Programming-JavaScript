class usuario{
    private nome: string;
    private cpf: string;
    private sexo: string;
 
    constructor(nome:string, cpf:string, sexo:string){
       this.nome = nome;
       this.cpf = cpf;
       this.sexo = sexo;
    }
    public getNome(): string{
       return this.nome
    }
    public getCpf(): string{
       return this.cpf;
    }
    public getSexo(): string{
       return this.sexo;
    }
 }
 
 const nome: string = prompt('Escreva o seu nome:');
 const cpf:string = prompt('Digite o seu CPF:');
 const sexo: string = prompt('Diga qual é o seu sexo:');
 
 const usuarioP: usuario = new usuario(nome, cpf, sexo);
 
console.log(`Escreva seu Nome ${usuarioP.getNome()}`)
document.write (`Nome: ${usuarioP.getNome()}`)
console.log(`Digite o seu CPF ${usuarioP.getCpf()}`);
document.write (`<br>CPF: ${usuarioP.getCpf()}`)
console.log(`Diga qual é o seu Sexo: ${usuarioP.getSexo()}`);
document.write (`<br>sexo: ${usuarioP.getSexo()}`)
 