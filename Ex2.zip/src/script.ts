class Aviao{
    private aviao: string;
    private fabricante: string;
    private Passageiros: number;
 
    constructor(modelo: string, fabricante: string, Passageiros: number){
       this.aviao = modelo;
       this.fabricante = fabricante;
       this.Passageiros = Passageiros;
    }
    public getModelo(): string{
       return this.aviao;
    }
    public getFabricante(): string{
       return this.fabricante;
    }
    public getPassageiros(): number{
       return this.Passageiros;
    }
 }
 
 const modelo: string = prompt ('Escreva o modelo do avião: ');
 const fabricante: string = prompt ('Escreva qual é a fabricante do avião: ');
 const Passageiros: number = Number (prompt('Digite quantos passageiros estão dentro do avião: '));
 
 const aviao: Aviao = new Aviao(modelo, fabricante, Passageiros);
 
 console.log(`O avião é: ${aviao.getModelo()}`);

 document.write(`O avião é: ${aviao.getModelo()}`);
 
 console.log(`O fabricante do avião é: ${aviao.getFabricante()}`);

 document.write(`<br>O fabricante do avião é: ${aviao.getFabricante()}`);
 
 console.log(`A quantidade de passageiros: ${aviao.getPassageiros()}`);

 document.write(`<br>A quantidade de passageiros: ${aviao.getPassageiros()}`);