class Funcionario{
    private nome: string;
    private empresa: string;
    private funcao: string;
    private salario: number;
 
    constructor(nome: string, empresa: string, funcao: string, salario: number){
       this.nome = nome;
       this.empresa = empresa;
       this.funcao = funcao;
       this.salario = salario;
    }
 
    public getNome(): string{
       return this.nome;
    }
 
    public getEmpresa(): string{
       return this.empresa;
    }
 
    public getFuncao(): string{
       return this.funcao;
    }
 
    public getSalario(): number{
       return this.salario;
    }
 }
 
 const nome = prompt('Diga o seu nome: ');
 const empresa = prompt('Digite o nome da empresa em que trabalha: ');
 const funcao = prompt('Diga qual é a sua função na empresa: ');
 const salario = Number(prompt('Digite o seu salário: '));
 
 const funcionario1: Funcionario = new Funcionario(nome, empresa, funcao, salario);
 
 console.log('----------- Dados do funcionário ------------');
 document.write('--------- Dados do funcionário ----------');
 
 console.log(`Nome: ${funcionario1.getNome()}`);

 document.write(`<br>Nome: ${funcionario1.getNome()}`);
 
 console.log(`Empresa: ${funcionario1.getEmpresa()}`);

 document.write(`<br>Empresa : ${funcionario1.getEmpresa()}`);
 
 console.log(`Função na empresa: ${funcionario1.getFuncao()}`);

 document.write(`<br>Função na empresa: ${funcionario1.getFuncao()}`);
 
 console.log(`Salário: ${funcionario1.getSalario()}`);

 document.write(`<br>Salário: ${funcionario1.getSalario()}`);