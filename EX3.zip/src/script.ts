class ProdutoE{
    private name: string;
    private preco: number;
 
    constructor(name: string, preco: number){
       this.name = name;
       this.preco = preco;
    }
 
    // NOME
    public getNome(): string{
       return this.name;
    }
 
    // PREÇO
    public getPreco(): number{
       return this.preco;
    }
 }
 
 const nome: string = prompt('Digite o nome do produto: ');
 const preco: number = Number(prompt('Digite o preço do produto: $ '));
 
 const produto: ProdutoE = new ProdutoE(nome, preco);
 
 console.log(`Produto: ${produto.getNome()}`);

 document.write(`Produto: ${produto.getNome()}`);
 
 console.log(`Preço: R$ ${produto.getPreco()}`);

 document.write(`<br>Preço: R$ ${produto.getPreco()}`);